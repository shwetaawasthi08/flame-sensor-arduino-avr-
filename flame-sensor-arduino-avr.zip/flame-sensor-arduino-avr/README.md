# Flame Sensor Fire Alarm (Arduino Uno / AVR)

A fire detection system using a flame sensor module. When a flame is detected, the buzzer sounds, the LED turns on and a warning shows on a 16x2 LCD. Otherwise the LCD shows that the system is safe.

The project is written in two ways:
- **AVR C** for Microchip Studio (`avr/flame_sensor_lcd/main.c`), no Arduino libraries
- **Arduino sketch** (`arduino/flame_sensor_lcd_parallel_arduino/`), using the built-in `LiquidCrystal` library

## Components
- Arduino Uno (ATmega328P, 16 MHz)
- Flame sensor module (digital output DO)
- IO board with buzzer
- 16x2 LCD (HD44780, 16-pin parallel)
- 10k potentiometer (LCD contrast)
- 220 ohm resistor (LCD backlight)

## Connections

| Part | Pin | Arduino |
|---|---|---|
| Flame sensor | VCC / GND | 5V / GND |
| Flame sensor | DO | D2 |
| IO board | 5V / GND | 5V / GND |
| IO board buzzer | input | D7 |
| LCD | VSS, RW, K | GND (K via backlight, see below) |
| LCD | VDD | 5V |
| LCD | V0 | Middle pin of 10k pot (outer pins to 5V and GND) |
| LCD | RS | D8 |
| LCD | E | D9 |
| LCD | D4 / D5 / D6 / D7 | A0 / A1 / A2 / A3 |
| LCD | A (backlight +) | 5V through 220 ohm |
| LCD | K (backlight -) | GND |

LCD pins D0 to D3 are not connected. All GND connections must be common.

## How it works
The flame sensor's DO pin goes LOW when a flame is detected.

| State | LCD line 1 | LCD line 2 | Buzzer / LED |
|---|---|---|---|
| Safe | `System: SAFE` | `No Fire Detected` | Off |
| Fire | `FIRE DETECTED!!` | `Move to safety!` | On |

The LCD is updated only when the state changes, so it does not flicker.

## Build and upload

**Microchip Studio**
1. File > New > Project > GCC C Executable Project, device ATmega328P.
2. Replace the contents of `main.c` with `avr/flame_sensor_lcd/main.c`.
3. Build with F7 and upload the `.hex` using avrdude or an ISP programmer.

**Arduino IDE**
1. Open `arduino/flame_sensor_lcd_parallel_arduino/flame_sensor_lcd_parallel_arduino.ino`.
2. Select Arduino Uno and the correct port, then upload.

## Troubleshooting
- Blank LCD or dark boxes: adjust the contrast potentiometer and check that RW is on GND.
- Buzzer reversed (on when safe): the buzzer is active-LOW, so invert the BUZZER_ON / BUZZER_OFF macros.
- No detection: adjust the potentiometer on the flame sensor module.

## Safety
This is a learning project. Do not rely on it as a real fire alarm.
